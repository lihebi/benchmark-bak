/* polymorph.h */

int main(int argc, char *argv[]);
void grok_commandLine(int argc, char *argv[]);
void convert_fileName(char *original);
int does_newnameExist(char *suspect);
int does_nameHaveUppers(char *suspect);
int is_fileHidden(char *suspect);


